# Ten-second cloud rendering test

This isolated Remotion sample is ready to deploy as a Docker web service. It contains no YouTube tokens, account credentials, upload logic or recurring scheduler. It does not change the existing project or local automation.

300 frames at 30 FPS, 1080×1920. Three animated scenes explain blue sky. The Tessa audio is prerecorded on the Mac and bundled; no macOS APIs are needed during cloud rendering. This tests remote rendering, not cloud-based script/image/voice generation.

Deploy the Dockerfile to the connected cloud provider. It starts an HTTP server using the provider's PORT and renders once on startup with one rendering worker. A service restart will render again. Select a plan with enough memory for Chrome; this package has not yet been built or rendered in a cloud environment. No hosting charges have been authorized or incurred by preparing this package.

After deployment, `/status.json` reports rendering state and runtime/provider details. `/sample.mp4` serves the completed render, and `/` shows a video player. A successful remote deployment and completed render are needed before calling this a cloud-rendered sample.

Checked: source TypeScript, server syntax, audio duration and fixed ten-second composition. Not checked: Docker build, cloud runtime and resulting video/audio playback.

Science source: https://spaceplace.nasa.gov/blue-sky/en/
Docker reference: https://www.remotion.dev/docs/docker
