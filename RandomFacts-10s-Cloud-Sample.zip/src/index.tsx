import React from 'react';
import {AbsoluteFill,Composition,Sequence,registerRoot,staticFile,useCurrentFrame} from 'remotion';
import {Audio} from '@remotion/media';
import {SkyVisual} from './SkyVisual';
import timing from './timing.json';
const words='Sunlight holds every rainbow color. Tiny air molecules scatter blue light more strongly than red. That is why the sky looks blue.'.split(' ');
const captions=Array.from({length:Math.ceil(words.length/4)},(_,i)=>words.slice(i*4,i*4+4).join(' '));
const Captions=()=>{
 const f=useCurrentFrame();const i=Math.floor((f/30)/(timing.audioSeconds/captions.length));
 if(i>=captions.length)return null;
 return <div style={{position:'absolute',left:96,right:160,bottom:320,padding:28,borderRadius:24,background:'#ffe4bd',fontSize:58,fontWeight:800,textAlign:'center',color:'#172b49'}}>{captions[i]}</div>;
};
const Sample=()=> <AbsoluteFill style={{background:'#e7f1ff',fontFamily:'Arial, sans-serif'}}>
 <div style={{position:'absolute',left:96,top:160,fontSize:32,fontWeight:800,letterSpacing:5,color:'#172b49'}}>RANDOMFACTS</div>
 <div style={{position:'absolute',left:96,right:160,top:280,fontSize:72,fontWeight:900,color:'#172b49'}}>Why is the sky blue?</div>
 <Sequence from={0} durationInFrames={90}><SkyVisual kind="spectrum" frames={90}/></Sequence>
 <Sequence from={90} durationInFrames={120}><SkyVisual kind="scattering" frames={120}/></Sequence>
 <Sequence from={210} durationInFrames={90}><SkyVisual kind="blue-view" frames={90}/></Sequence>
 <Captions/><Audio src={staticFile('narration.wav')}/>
</AbsoluteFill>;
const Root=()=> <Composition id="CloudSample" component={Sample} durationInFrames={300} width={1080} height={1920} fps={30}/>;
registerRoot(Root);
