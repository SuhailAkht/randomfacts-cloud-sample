import React from 'react';
import {Img, staticFile, useCurrentFrame, interpolate} from 'remotion';
export type SkyKind = 'sky-reveal' | 'spectrum' | 'scattering' | 'blue-view' | 'sunset';
export const isSkyKind=(kind:string):kind is SkyKind=>['sky-reveal','spectrum','scattering','blue-view','sunset'].includes(kind);
const colors=['#ff756c','#ffb34f','#ffe76b','#7ceaa3','#54baff','#aaa0ff'];
const wave=(y:number,period:number,phase:number)=>Array.from({length:121},(_,i)=>`${i===0?'M':'L'} ${190+i*4.6} ${y+12*Math.sin(i*4.6/period*Math.PI*2+phase)}`).join(' ');
const Tag:React.FC<{y:number;children:React.ReactNode}>=({y,children})=><div style={{position:'absolute',top:y,left:45,right:45,textAlign:'center',fontSize:32,fontWeight:800,color:'#f1f6ff',lineHeight:1.3}}>{children}</div>;
export const SkyVisual:React.FC<{kind:SkyKind;frames:number}>=({kind,frames})=>{
 const frame=useCurrentFrame();const p=Math.min(1,frame/Math.max(1,frames-1));
 const landscape=['sky-reveal','blue-view','sunset'].includes(kind);
 return <div style={{position:'absolute',left:70,right:120,top:470,height:950,overflow:'hidden',borderRadius:48,background:'#101e3e',boxShadow:'0 18px 45px #15294620'}}>
  {landscape && <Img src={staticFile('illustrations/sky/blue-landscape.png')} style={{position:'absolute',width:'100%',height:'100%',objectFit:'cover',scale:1.03+0.04*p,filter:kind==='sunset'?'sepia(0.6) saturate(1.5) brightness(0.75)':'none'}}/>}
  {kind==='sky-reveal' && <>
   <Img src={staticFile('illustrations/space/sun.png')} style={{position:'absolute',width:185,height:185,top:90,left:570,rotate:`${frame/12}deg`}}/>
   <div style={{position:'absolute',left:80,right:80,top:360,textAlign:'center',fontSize:78,fontWeight:900,color:'white',textShadow:'0 5px 14px #183b7380',opacity:interpolate(frame,[0,22],[0,1],{extrapolateRight:'clamp'})}}>It starts with<br/>sunlight.</div>
  </>}
  {kind==='spectrum' && <>
   <Tag y={65}>WHITE LIGHT • MANY COLORS</Tag>
   <svg width="890" height="950" style={{position:'absolute'}}>
    <path d="M70 400 L340 400" stroke="white" strokeWidth="13" strokeDasharray="18 8" strokeDashoffset={-frame*3}/>
    <path d="M330 290 L330 510 L470 400 Z" fill="#bbdcff38" stroke="#c9e3ff" strokeWidth="4"/>
    {colors.map((c,i)=><path key={c} d={`M430 400 L780 ${235+i*67}`} stroke={c} strokeWidth="12" strokeDasharray="20 6" strokeDashoffset={-frame*3}/>) }
   </svg>
   <Tag y={650}>A prism reveals the colors<br/>already in sunlight.</Tag>
   <div style={{position:'absolute',left:100,right:100,bottom:80,display:'flex',justifyContent:'space-between',color:'#e8f2ff',fontSize:30}}><span>RED</span><span>→</span><span>VIOLET</span></div>
  </>}
  {kind==='scattering' && <>
   <Tag y={50}>AIR MOLECULES SCATTER LIGHT</Tag>
   <svg width="890" height="950" style={{position:'absolute'}}>
    {Array.from({length:24},(_,i)=><g key={i} opacity={0.35} transform={`translate(${95+(i*157)%700},${220+(i*91)%440})`}><circle r="10" fill="#a3c4e4"/><circle cx="13" cy="6" r="8" fill="#6e9cc6"/></g>)}
    <path d={wave(310,80, -frame/9)} stroke="#ff8376" strokeWidth="7" fill="none"/>
    <path d={wave(480,30, -frame/7)} stroke="#63bdff" strokeWidth="7" fill="none"/>
    {[-2.7,-1.9,-0.8,0.4,1.2,2.3].map((a,i)=><path key={i} d={`M510 480 L${510+240*Math.cos(a)} ${480+240*Math.sin(a)}`} fill="none" stroke="#63bdff" strokeWidth="5" strokeDasharray="12 15" strokeDashoffset={-frame*3} opacity={0.7}/>) }
    <circle cx="510" cy="480" r="18" fill="#d5edff"/>
   </svg>
   <Tag y={715}>Blue scatters more strongly<br/>than red.</Tag>
   <div style={{position:'absolute',bottom:55,left:0,right:0,textAlign:'center',color:'#b9cce7',fontSize:25}}>Simplified view • molecules and waves not to scale</div>
  </>}
  {kind==='blue-view' && <>
   <div style={{position:'absolute',inset:0,background:'linear-gradient(#17396970, transparent 80%)'}}/>
   <Tag y={65}>BLUE LIGHT ARRIVES<br/>FROM ACROSS THE SKY</Tag>
   <svg width="890" height="950" style={{position:'absolute'}}>
    {[120,290,600,770].map((x,i)=><g key={x}><circle cx={x} cy={270+i%2*80} r="12" fill="#e2f4ff"/><path d={`M${x} ${290+i%2*80} L445 690`} stroke="#8ad7ff" strokeWidth="7" strokeDasharray="12 18" strokeDashoffset={-frame*3}/></g>)}
    <path d="M340 720 Q445 610 550 720 Q445 830 340 720Z" fill="#f6fbff" stroke="#19385f" strokeWidth="6"/>
    <circle cx="445" cy="720" r="38" fill="#59acdf"/><circle cx="445" cy="720" r="18" fill="#172a49"/>
   </svg>
   <div style={{position:'absolute',bottom:42,left:55,right:55,padding:18,borderRadius:20,background:'#f2f7ffed',color:'#19385f',fontSize:29,fontWeight:800,textAlign:'center'}}>Our eyes are more sensitive to blue than violet.</div>
  </>}
  {kind==='sunset' && <>
   <div style={{position:'absolute',inset:0,background:'linear-gradient(#16254fd9 0%,#c85f6777 45%,#ffac5988 78%,#3a233b66 100%)'}}/>
   <Tag y={65}>SUNSET: A LONGER PATH<br/>THROUGH THE ATMOSPHERE</Tag>
   <Img src={staticFile('illustrations/space/sun.png')} style={{position:'absolute',top:590,left:690,width:145,height:145}}/>
   <svg width="890" height="950" style={{position:'absolute'}}>
    {[0,1,2].map(i=><path key={i} d={`M710 ${650+i*20} L100 ${610+i*20}`} stroke={['#ffce8a','#ff9d72','#ff7b70'][i]} strokeWidth="7" strokeDasharray="18 12" strokeDashoffset={frame*3}/>) }
    {[240,400,550].map((x,i)=><path key={x} d={`M${x} 640 L${x-80} ${340+i*45}`} stroke="#79c5ff" strokeWidth="5" strokeDasharray="12 16" strokeDashoffset={-frame*3} opacity={0.75}/>) }
   </svg>
   <div style={{position:'absolute',bottom:55,left:55,right:55,padding:20,borderRadius:20,background:'#332942df',color:'#ffe4bd',fontSize:32,fontWeight:800,textAlign:'center'}}>More blue scattered away.<br/>More red and orange reach us.</div>
  </>}
 </div>;
};
