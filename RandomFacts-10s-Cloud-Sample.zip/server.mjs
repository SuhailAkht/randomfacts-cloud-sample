import http from 'node:http';
import os from 'node:os';
import {spawn} from 'node:child_process';
import {mkdirSync,createReadStream,statSync,writeFileSync} from 'node:fs';
mkdirSync('out',{recursive:true});
let state='rendering';
const proof={startedAt:new Date().toISOString(),platform:os.platform(),architecture:os.arch(),provider:process.env.RENDER?'Render':'Unverified runtime',serviceId:process.env.RENDER_SERVICE_ID??null,composition:'CloudSample',durationSeconds:10};
http.createServer((req,res)=>{
 if(req.url==='/sample.mp4' && state==='complete'){
  res.writeHead(200,{'Content-Type':'video/mp4','Content-Length':statSync('out/sample.mp4').size});createReadStream('out/sample.mp4').pipe(res);return;
 }
 if(req.url==='/status.json'){
  res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({...proof,state}));return;
 }
 res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});
 res.end(`<html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body style="font-family:Arial;background:#e7f1ff;text-align:center;padding:32px"><h1>RandomFacts · 10-second cloud test</h1><p>${state}</p>${state==='complete'?'<video controls playsinline style="max-height:75vh;max-width:100%" src="/sample.mp4"></video>':'<p>Refresh after rendering finishes.</p>'}<p><a href="/status.json">Render status</a></p></body></html>`);
}).listen(Number(process.env.PORT??10000),'0.0.0.0');
const child=spawn('node_modules/.bin/remotion',['render','src/index.tsx','CloudSample','out/sample.mp4','--codec=h264','--pixel-format=yuv420p','--concurrency=1'],{stdio:'inherit'});
child.on('error',()=>{state='failed';});
child.on('exit',code=>{state=code===0?'complete':'failed';proof.completedAt=new Date().toISOString();writeFileSync('out/render-status.json',JSON.stringify({...proof,state},null,2));});
